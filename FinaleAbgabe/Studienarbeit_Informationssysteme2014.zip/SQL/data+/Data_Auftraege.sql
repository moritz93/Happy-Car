﻿INSERT INTO Aufträge (Modell_ID, Anzahl, KundenID, mitarbeiterID) VALUES
-- (Modell_ID, Anzahl, KundenID, MitarbeiterID)
-- Verwaltungsangestellte 3, 8
-- Kunden 1, 4, 6, 9
-- Modell_ID 1-5
	(1, 2, 1, 3),
	(2, 3, 4, 8),
	(3, 1, 6, 3),
	(4, 5, 9, 8),
	(5, 10, 9, 8),
	(1, 2, 1, 3),
	(2, 3, 4, 8),
	(3, 1, 6, 3),
	(4, 5, 9, 8),
	(5, 10, 9, 8);
	
	
